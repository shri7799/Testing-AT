package JdbcConnection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class PracticeProject2 {

	public static void main(String[] args) {
		       
		try {
				Class.forName("com.mysql.cj.jdbc.Driver");
				// Connect the DB
				String dburl = "jdbc:mysql://localhost:3306/ecommerce";
				String username = "root";
				String password = "Shri@7799";
				Connection con = DriverManager.getConnection(dburl, username, password);
				System.out.println("Succesfully connected");

				String query = "select * from products";               

				// send query to the DB

				Statement stmt = con.createStatement();

				ResultSet rs = stmt.executeQuery(query);

				while (rs.next()) {

					System.out.println( rs.getString("id") +" "+ rs.getString("name") +" "+rs.getString("price"));


					

				}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}

}
