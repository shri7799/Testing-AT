package AccessModifier;

public class Access {
	int hours =3;
	int mins = 38;
	public String name = "Shridhar"; // can be accessed from same class or different class within same package or different package
	public String tool = "Eclipse";
	
	private int a =32;	// can be accessed only within the same class
	private int b = 85; // can be accessed only within the same class
	
	protected int x = 100; // can be accessed from different  class of the same package
	protected int z = 200;

}
