package AccessModifier;

public class AccessModifierExamples {
	public static void main(String[] args) {
		
		Access obj = new Access();
		
		System.out.println(obj.hours);
		System.out.println(obj.mins);
		
		System.out.println(obj.name);
		System.out.println(obj.tool);
		
		System.out.println(obj.x);
		System.out.println(obj.z);



}
}
