package PracticePrograms;

public class DoWhileExample {

	public static void main(String[] args) {
		int i = 1; // Initialize a variable to start from 1

        do {
            System.out.println(i);
            i++; // Increment the value of 'i' by 1 in each iteration
        } while (i <= 5); // prints values until 5

	}

}
