package PracticePrograms;

public class WhileLoopExample {

	public static void main(String[] args) {
		int i = 1; // Initialize a variable i to start from 1

        // Use a while loop to print numbers from 1 to 10
        while (i <= 10) {
            System.out.println(i);
            i++; // Increment the value of 'i' by 1 in each iteration
        }
	}
}
