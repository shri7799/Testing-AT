package PracticePrograms;

public class ForLoopExample {

	public static void main(String[] args) {
		 // Using  for loop to print numbers from 1 to 5
        for (int i = 1; i <= 5; i++) {  // initializing i value to 1 , loop until i value is equal to or less 5
            System.out.println(i);

	}
	}
}
