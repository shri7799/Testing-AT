package PracticePrograms;

public class TypeCastingExample {

	public static void main(String[] args) {
		 // Implicit type casting
        int intValue = 10;
        double doubleValue = intValue; // Implicitly type casting integer to double

        float floatValue = 20.5f;
        double doubleValue2 = floatValue; // Implicitly cast float to double

        long longValue = 123456789L;
        double doubleValue3 = longValue; // Implicitly cast long to double

        short shortValue = 100;
        int intValue2 = shortValue; // Implicitly cast short to integer

        byte byteValue = 5;
        short shortValue2 = byteValue; // Implicitly cast byte to short

        System.out.println("Implicit Type Casting:");
        System.out.println("intValue : " + intValue);
        System.out.println("doubleValue : " + doubleValue);
        System.out.println("floatValue : " + floatValue);
        System.out.println("doubleValue2 : " + doubleValue2);
        System.out.println("longValue : " + longValue);
        System.out.println("doubleValue3 : " + doubleValue3);
        System.out.println("shortValue : " + shortValue);
        System.out.println("intValue2 : " + intValue2);
        System.out.println("byteValue : " + byteValue);
        System.out.println("shortValue2 : " + shortValue2);

        // Explicit type casting
        double doubleValue4 = 45.67;
        int intValue3 = (int) doubleValue4; // Explicitly cast double to integer

        double doubleValue5 = 123.45;
        float floatValue2 = (float) doubleValue5; // Explicitly cast double to float

        long longValue2 = 9876543210L;
        int intValue4 = (int) longValue2; // Explicitly cast long to integer

        short shortValue3 = 300;
        byte byteValue2 = (byte) shortValue3; // Explicitly cast short to byte

        System.out.println("\nExplicit Type Casting:");
        System.out.println("doubleValue4 : " + doubleValue4);
        System.out.println("intValue3 : " + intValue3);
        System.out.println("doubleValue5 : " + doubleValue5);
        System.out.println("floatValue2 : " + floatValue2);
        System.out.println("longValue2 : " + longValue2);
        System.out.println("intValue4 : " + intValue4);
        System.out.println("shortValue3 : " + shortValue3);
        System.out.println("byteValue2 : " + byteValue2);

	}

}
