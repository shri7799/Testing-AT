package ExceptionHandling;

public class TryCatchExample {
	public static void main(String[] args) {
		// Handling the exception using try-catch block
        try {
            int numerator = 10;
            int denominator = 0;
            int result = numerator / denominator; // This will throw an ArithmeticException
            System.out.println("Result: " + result); // This line won't be executed
        } catch (ArithmeticException e) {
            System.out.println("An arithmetic exception occurred: " + e.getMessage());
        }
        
        try {
            String str = null;
            System.out.println(str.length()); // This will throw a NullPointerException
        } catch (NullPointerException e) {
            System.out.println("A null pointer exception occurred: " + e.getMessage());
        }
	}
}
