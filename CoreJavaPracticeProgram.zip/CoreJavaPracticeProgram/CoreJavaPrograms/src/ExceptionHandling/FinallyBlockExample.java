package ExceptionHandling;

public class FinallyBlockExample {
public static void main(String[] args) {
	try {
        int result = divide(10, 2);
        System.out.println("Result: " + result);
    } catch (ArithmeticException e) {
        System.out.println("Caught an ArithmeticException: " + e.getMessage());
    } finally {
        System.out.println("This block will always execute.");
    }
}

static int divide(int numerator, int denominator) {
    if (denominator == 0) {
        throw new ArithmeticException("Cannot divide by zero.");
    }
    return numerator / denominator;
}
}

