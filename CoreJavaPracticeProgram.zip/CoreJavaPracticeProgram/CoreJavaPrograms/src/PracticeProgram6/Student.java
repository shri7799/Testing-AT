package PracticeProgram6;
 // program to understanding creating class , values and methods
public class Student { // creating a class named student
	
 String name;
 String address;
 int marks;

void studying()
{
	System.out.println("student is studying");
}
void playing()
{
	System.out.println("student is playing cricket");
}
void sleeping()
{
	System.out.println("student is sleeping");
}
 
}
