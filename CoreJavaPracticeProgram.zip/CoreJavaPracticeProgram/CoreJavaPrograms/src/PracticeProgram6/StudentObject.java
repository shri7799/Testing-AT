package PracticeProgram6;

//program to creating object and passing the parameter to the constructor
public class StudentObject{
	public StudentObject(String name)
	{
		//this constructor has one parameter, name
		System.out.println("Student name is :" +name);
	}
	
	public static void main(String[] args) {
		// following statement would create an object student
		StudentObject student = new StudentObject("shridhar");
	}

}
