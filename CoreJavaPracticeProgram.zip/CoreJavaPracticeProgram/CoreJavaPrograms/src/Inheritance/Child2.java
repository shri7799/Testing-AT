package Inheritance;

public class Child2 extends Grandparent{
	void displayChild() {
        System.out.println("This is the child2 class");
    }
	

}
