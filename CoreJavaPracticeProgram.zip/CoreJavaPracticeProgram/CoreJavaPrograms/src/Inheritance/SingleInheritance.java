package Inheritance;

public class SingleInheritance {
public static void main(String[] args) {
        
		// Single Inheritance
		
        Child child = new Child();
        child.displayParent();
        child.displayChild();
}
}
