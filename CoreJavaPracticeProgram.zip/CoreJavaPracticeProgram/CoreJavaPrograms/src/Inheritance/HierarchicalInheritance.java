package Inheritance;

public class HierarchicalInheritance {

	public static void main(String[] args) {
		 Parent2 parent2 = new Parent2();
	      Child2 child2 = new Child2();
	      
	      parent2.displayGrandparent();
	        parent2.displayParent();

	        child2.displayGrandparent();
	        child2.displayChild();

	}

}
