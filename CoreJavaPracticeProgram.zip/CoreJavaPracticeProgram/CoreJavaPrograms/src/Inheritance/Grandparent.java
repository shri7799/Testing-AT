package Inheritance;

public class Grandparent {
	void displayGrandparent() {
        System.out.println("This is the grandparent class");
    }

}
