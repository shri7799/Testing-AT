package Inheritance;

public class Child extends Parent {
	
	void displayChild() {
		
        System.out.println("This is the child class");
    }
	
}
