package Inheritance;

public class Parent2 extends Grandparent{
	 void displayParent() {
	        System.out.println("This is the parent2 class");
	    }
	
}
