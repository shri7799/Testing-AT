package Inheritance;
 // creating a parent class

public class Parent {
	
 void displayParent() {
	 System.out.println("this is parent class");
 }
}
