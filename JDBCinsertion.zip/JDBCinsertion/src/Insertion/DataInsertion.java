package Insertion;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class DataInsertion {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		
		Connection con = null;
		PreparedStatement ps=null;
		String dburl = "jdbc:mysql://localhost:3306/ecommerce";
		String username = "root";
		String password = "Shri@7799";
		String sql = "insert into products values(4, 'Acer' , 14.99)";
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection(dburl, username, password);
			System.out.println("Succesfully connected");

			ps=con.prepareStatement(sql);
			

			int nora = ps.executeUpdate();
			System.out.println(nora +" row(s) inserted");

	}
	catch (Exception e) {
		e.printStackTrace();
	}


	}

}
