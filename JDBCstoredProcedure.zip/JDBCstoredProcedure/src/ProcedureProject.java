
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class ProcedureProject {

	public static void main(String[] args) throws SQLException, ClassNotFoundException {
		// Load the DB
		Class.forName("com.mysql.cj.jdbc.Driver");
		// Connect the DB
		String dburl = "jdbc:mysql://localhost:3306/ecommerce";
		String username = "root";
		String password = "Shri@7799";
		String query = "Call allproducts()";
		
		
		Connection conn = DriverManager.getConnection(dburl, username, password);
		System.out.println("Succesfully connected");
		
		Statement stmt = conn.createStatement();
		
		ResultSet rs = stmt.executeQuery(query);
		
		while (rs.next()) {

			System.out.print("id:  " + rs.getInt("id") + "\t");

			System.out.print("name:  " + rs.getString("name") + "\t");

			System.out.print("price:  " + rs.getFloat("price") + "\t");

			

		}

		conn.close();


	}

}
